export const table = process.env.TABLE;
export const region = process.env.REGION;